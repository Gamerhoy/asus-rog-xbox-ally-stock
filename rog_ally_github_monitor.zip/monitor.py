import json, re
from datetime import datetime, timezone
from pathlib import Path
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent
STATUS = ROOT / "site" / "status.json"
HISTORY = ROOT / "history.json"
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128 Safari/537.36"}
TIMEOUT = 25
TARGET_PRICE = 799.0

RETAILERS = [
 {"key":"courts","retailer":"COURTS Singapore","url":"https://www.courts.com.sg/asus-7in-amd-z2-a-processor-16gb-ram-512gb-ssd-rog-xbox-ally-2025---rc73ya-nh002w-IP214790.html","kind":"html"},
 {"key":"challenger","retailer":"Challenger / Hachi.tech","url":"https://online.challenger.sg/products/asus-rog-xbox-ally-rc73ya-nh002w-z2-a-16gb-512gb-wht?variant=41769333981259","kind":"shopify","variant_id":41769333981259},
 {"key":"gaincity","retailer":"Gain City","url":"https://www.gaincity.com/asus-rog-xbox-ally-gaming-handheld-white-rc73ya-nh002w-tb0011284","kind":"html"},
]

def request(url):
    r = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    return r

def price_from(text):
    found = re.findall(r"(?:S\$|SGD\\s*)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)", text, re.I)
    vals = [float(x.replace(",", "")) for x in found]
    return TARGET_PRICE if TARGET_PRICE in vals else (min(vals) if vals else None)

def base_result(shop):
    return {"key":shop["key"],"retailer":shop["retailer"],"url":shop["url"],
            "status":"unknown","model_verified":False,"price_sgd":None,
            "details":"No dependable public stock signal was detected."}

def check_html(shop):
    out = base_result(shop)
    try:
        soup = BeautifulSoup(request(shop["url"]).text, "html.parser")
        text = " ".join(soup.stripped_strings)
        low = text.lower()
        out["model_verified"] = "rc73ya-nh002w" in low
        out["price_sgd"] = price_from(text)
        if not out["model_verified"]:
            out["details"] = "Page loaded, but exact model code was not found."
        elif any(x in low for x in ("out of stock","sold out","currently unavailable","temporarily unavailable","notify me when available")):
            out.update(status="out_of_stock", details="Product page indicates unavailable.")
        elif any(x in low for x in ("add to cart","add to bag","buy now","available for delivery")):
            out.update(status="in_stock", details="A purchase action is visible on the product page.")
        else:
            out["details"] = "Exact model found, but page did not expose a clear stock signal."
    except Exception as e:
        out["details"] = "Check failed: " + type(e).__name__
    return out

def check_shopify(shop):
    out = base_result(shop)
    endpoint = shop["url"].split("?")[0].rstrip("/") + ".js"
    try:
        data = request(endpoint).json()
        variant = next((v for v in data.get("variants",[]) if int(v.get("id",-1)) == shop["variant_id"]),None)
        title = str(data.get("title","")).lower()
        out["model_verified"] = "rc73ya-nh002w" in title
        if not variant:
            out["details"] = "Configured product variant was not returned by the public endpoint."
            return out
        if isinstance(variant.get("price"),(int,float)):
            out["price_sgd"] = round(variant["price"]/100,2)
        if not out["model_verified"]:
            out["details"] = "Variant found, but exact model code was not verified."
        elif variant.get("available") is True:
            out.update(status="in_stock",details="Configured Shopify variant is marked available.")
        elif variant.get("available") is False:
            out.update(status="out_of_stock",details="Configured Shopify variant is marked unavailable.")
        else:
            out["details"] = "Variant endpoint did not provide availability."
    except Exception as e:
        out["details"] = "Check failed: " + type(e).__name__
    return out

def read_json(path, fallback):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return fallback

def main():
    STATUS.parent.mkdir(parents=True,exist_ok=True)
    old = read_json(STATUS,{"retailers":[]})
    old_map = {x.get("key"):x for x in old.get("retailers",[])}
    results = []
    transitions = []
    for shop in RETAILERS:
        item = check_shopify(shop) if shop["kind"]=="shopify" else check_html(shop)
        previous = old_map.get(item["key"],{})
        if previous.get("status")=="out_of_stock" and item["status"]=="in_stock":
            transitions.append({"retailer":item["retailer"],"url":item["url"],
                "message":item["retailer"]+" may now have the ASUS ROG Ally in stock."})
        results.append(item)
    payload = {"product":"ASUS ROG Xbox Ally RC73YA-NH002W","target_price_sgd":TARGET_PRICE,
        "checked_at":datetime.now(timezone.utc).isoformat(),"interval_minutes":30,
        "retailers":results,"new_stock_transitions":transitions,
        "note":"Public product-page checks only. Branch inventory is not checked; Unknown is not the same as out of stock."}
    STATUS.write_text(json.dumps(payload,indent=2),encoding="utf-8")
    history = read_json(HISTORY,[])
    history.append({"checked_at":payload["checked_at"],"statuses":{x["key"]:x["status"] for x in results}})
    HISTORY.write_text(json.dumps(history[-500:],indent=2),encoding="utf-8")
    print(json.dumps(payload,indent=2))

if __name__=="__main__": main()
