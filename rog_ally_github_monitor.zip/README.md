# ROG Ally Singapore Stock Monitor

A GitHub-hosted monitor for the ASUS ROG Xbox Ally **RC73YA-NH002W**, target price **S$799**. It checks public product-page signals at COURTS, Challenger/Hachi.tech and Gain City, then publishes a browser dashboard. It runs every 30 minutes.

## Limitations
- Public product pages only; it does not access private retailer inventory systems.
- It does not check branch-level stock at Junction 8, AMK Hub, NEX, Orchard or Funan.
- If a page blocks requests or has no clear signal, the result is **Unknown**, not an assumed out-of-stock result.
- Harvey Norman and the official ASUS Singapore store are not included because a verified matching product URL was not available when this starter was prepared.
- Price extraction is best-effort. Confirm model, final price and pickup/delivery details on the retailer page.

## Setup using the GitHub website (no terminal)
1. Sign in to GitHub and create a new repository. A public repository is the simplest option for GitHub Pages.
2. Extract this ZIP using File Explorer.
3. In the repository, choose **Add file → Upload files**.
4. Upload the extracted contents while preserving folders: `monitor.py`, `requirements.txt`, `history.json`, `site/index.html`, and `.github/workflows/monitor.yml`.
5. Commit to the default branch (usually `main`).
6. Open **Settings → Pages** and set the source to **GitHub Actions**.
7. Open **Actions**, enable workflows if prompted, select **Check ROG Ally stock**, then choose **Run workflow** once.
8. When the run succeeds, find the website URL under **Settings → Pages**. It will look like `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

After the first successful run, checks are scheduled every 30 minutes. Open the site and press **Refresh status** to fetch the latest published result.

## Troubleshooting
- If a run fails, open **Actions → Check ROG Ally stock** and inspect the failed step.
- If a retailer shows Unknown, open its product page manually; it may block automated checks or use a different page layout.
- Scheduled runs may be delayed and are not guaranteed to start at the exact minute.
